
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>가입완료</title>
</head>
<body>
    <p>가입이 완료 되었습니다.</p>
    <p>
        <a href="../index.php">메인 페이지로 이동</a>
        <a href="../login/login.php">로그인 페이지로 이동</a>
    </p>
</body>
</html>